﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PetShop.Models;
using PetShop.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Controllers
{
    public class UserManageController : Controller
    {
        UserManager<AppUser> userManager;
        RoleManager<IdentityRole> roleManager;

        public UserManageController(UserManager<AppUser> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet] //返回修改前个人信息
        public async Task<IActionResult> Modify()
        {
            //找到修改的用户 User 系统定义的用户对象
            var user = await userManager.GetUserAsync(User);
            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> Modify(AppUser user)
        {
            //更新用户的信息 根据user信息 在找到数据库user 去更新
            //找到修改的用户 User 系统定义的用户对象
            var appUser = await userManager.FindByIdAsync(user.Id);
            appUser.RealName = user.RealName;
            appUser.Address = user.Address;
            var result = await userManager.UpdateAsync(appUser);
            ViewBag.Msg = result.Succeeded;
            return View();
        }

        [HttpGet] //返回修改密码个人信息
        public async Task<IActionResult> ChangePwd()
        {
            //找到修改的用户 User 系统定义的用户对象
            var user = await userManager.GetUserAsync(User);
            //转成vm对象
            ChangePwdVM vm = new ChangePwdVM()
            {
                UserName = user.UserName
            };
            return View(vm);
        }

        [HttpPost]
        public async Task<IActionResult> ChangePwd(ChangePwdVM vm)
        {
            //找用户的信息 User 根据user信息 更新密码
            var user = await
                  userManager.FindByNameAsync(vm.UserName);
            //找到修改的用户 根据user信息 更新密码
            var result = await userManager
                  .ChangePasswordAsync(user, vm.OldPassword, vm.NewPassword);
            ViewBag.Msg = result.Succeeded;
            return View();
        }
        public async Task<IActionResult> ShowOrder()
        {
            AppUser appUser = await userManager.GetUserAsync(User);
            var user = await userManager.Users.Include(u => u.Orders).FirstOrDefaultAsync(u => u.Id == appUser.Id);
            return View(user.Orders);
           
        }
    }
}

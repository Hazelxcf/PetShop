﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PetShop.Models;
using PetShop.Tools;
using PetShop.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetShop.Controllers
{ //Session 会话  服务器端给你内存 ，
  //你可以存放你的数据（a=5 ,b=3) 任何一个页面都可以读写Session 跨页面访问
  //当你不在访问服务器 Session被回收 读写字符串  对象session不行
  //1 下包 Session 2.配置  services.AddSession();  app.UseSession();  3.使用
 //购物车 是个对象，集合  Session被扩展 放对象
    public class HomeController : Controller
    {
        DogDbContext context;//访问数据库 读取 数据
        
        private readonly UserManager<AppUser> _userManager;
        public HomeController(DogDbContext context, UserManager<AppUser> userManager)
        {
            this.context = context;
            _userManager = userManager;
        }
      
        //分类别显示所有得宠物

        public IActionResult Index()
        {
           var dogs = context.Dogs.ToList();
           var dogTypes = context.DogType.ToList();
            //组成一个视图model得对象 传递给视图
            HomeIndexVM vm = new HomeIndexVM() {Dogs=dogs,DogTypes = dogTypes };
            //写Session 放一个变量进Session username "tom"
           
            //HttpContext.Session.Set("username", Encoding.Default.GetBytes("tom"));
               
                return View(vm);
        }
        //根据类型显示某种类型的狗
         public IActionResult GetDogsByType(int id)
        { //取值
           // HttpContext.Session.TryGetValue("username", out var s);
            var doglist = context.Dogs.ToList();
            if (id != 0)
            {
                 doglist = context.Dogs
                .Where(t => t.TypeId == id).ToList();
                //关联查询
              /* var type = context.DogType
                        .Where(d => d.TypeId == id)
                        .Include(type => type.Dogs)
                        .ToList().First();
                doglist = type.Dogs;*/

            }
            HomeIndexVM vm = new HomeIndexVM()
            {
                Dogs = doglist,
                DogTypes = context.DogType.ToList()
            };
            //Index 表示显示页面是Index,vm表示传递给View的数据
            return View("Index", vm);//

        }
        /// <summary>
        /// 根据宠物名字进行搜索
        /// </summary>
        /// <param name="dogName"></param>
        /// <returns></returns>
        public IActionResult Search(string dogName)
        {//
            List<Dog> list = null;
            //添加查询代码，完成根据狗的名称dogName，查询所有包括这个名字的dog，存到list中
            list = context.Dogs.
                Where(b => b.Name.Contains(dogName)).ToList();
            HomeIndexVM vm = new HomeIndexVM()
            {
                Dogs = list,
                DogTypes = context.DogType.ToList()
            };
            return View("Index", vm);//返回视图到Index，并传递数据list
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

       
        

        //点击数量+号或点击数量-号或自己输入一个值
        [HttpPost]
        public ActionResult IncreaseOrDecreaseOne(int id, int quantity)
        {
            var cart = HttpContext.Session.GetObject<Cart>("cartlist");
            var product = context.Dogs.Find(id);
            cart.IncreaseOrDecreaseOne(product, quantity);

            HttpContext.Session.SetObject<Cart>("cartlist", cart);
            return Json(new
            {
                msg = true
            });
        }
        //添加要买的商品到购物车
        public IActionResult AddCart(int id, string returnUrl,int quantity)
        {
            var product = context.Dogs.Find(id);
         
            var cart = HttpContext.Session.GetObject<Cart>("cartlist");
            if (cart == null)
            {
                cart = new Cart();
            }
            if (quantity == 0)
                quantity = 1;
            cart.AddItem(product, quantity);
            HttpContext.Session.SetObject<Cart>("cartlist", cart);

            // return Json(cartIndexVm);
            return RedirectToAction("MyCart", new { returnUrl });

            // return View(cart);
        }
        //购物车
        public ActionResult MyCart(string returnUrl)
        {
            var cart = HttpContext.Session.GetObject<Cart>("cartlist");
            if (cart == null)
            {
                cart = new Cart();
            }
            return View(new CartIndexVm
            {
                Cart = cart,
                ReturnUrl = returnUrl
            });
        }
        //购物车中移除一行商品
        public IActionResult DelOne(int id)
        {
            var cart = HttpContext.Session.GetObject<Cart>("cartlist");
            if (cart == null)
            {
                cart = new Cart();
            }
            else
                cart.RemoveLine(id);


            HttpContext.Session.SetObject<Cart>("cartlist", cart);
            return Json(new
            {
                msg = true
            });
        }
        //登录后创建用户的订单
        [Authorize]
        public async Task<IActionResult> CreateOrderAsync(string returnUrl)
        {
            AppUser user = await _userManager.GetUserAsync(User);
            var cart = HttpContext.Session.GetObject<Cart>("cartlist");
            var sum = cart.ComputeTotalPrice();
            var detailList = cart.Lines.ToList().Select(p => new OrderDetail { DogId = p.Id, DogName = p.Name, Price = p.Price, Quantity = p.Quantity }).ToList();
            Order order = new Order { Money = (double)sum, CreateTime = DateTime.Now, status = false, AppUser = user, OrderDetails = detailList };
            context.Orders.Add(order);
            context.SaveChanges();
            return View("Order");
            //return RedirectToAction("Index");
        }
        //显示狗的详情
        public IActionResult Detail(int id)
        {

            /// 根据id查询一条狗信息并保存到dog对象中
            var dog = context.Dogs.Find(id);
            //根据dog的TYpeId查询TypeName 送到viewBag
            ViewBag.TypeName = context.DogType.Find(dog.TypeId).TypeName;
            //修改返回，将dog对象并传送到view的Model中
            return View(dog);
        }

    }
}

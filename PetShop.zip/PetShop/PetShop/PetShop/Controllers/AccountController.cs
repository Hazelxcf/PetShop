﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PetShop.Models;
using PetShop.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Controllers
{
    public class AccountController : Controller
    {
        //用户服务
        UserManager<AppUser> userManager;
        //登录服务
        SignInManager<AppUser> signInManager;

        
        public AccountController(UserManager<AppUser> userManager
            , SignInManager<AppUser> signInManager)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
        }
        //注册
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel vm)
        {//保存到数据库 appUser对象 然后把vm的值给user

            AppUser user = new AppUser()
            {
                UserName = vm.UserName,
                RealName = vm.RealName,
                Address = vm.Address
            };
            //创建用户 异步
            var result = await userManager
                   .CreateAsync(user, vm.Password);

            //给用户分配角色 普通用户
          await  userManager.AddToRoleAsync(user, "NormalUser");

            //表示是否成功 true flase
            if (result.Succeeded)
                return RedirectToAction("Login");
            else
            {
                ViewBag.Msg = "注册失败";
                return View();
            }
           
        }

        //登录
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel vm,string returnUrl)
        {//1 vm的用户名，去到数据库找 appUser对象 ，看是否有这个用户

            var user = await userManager.FindByNameAsync(vm.UserName);
            if (user != null) //找到了
            {
                //2 判断密码 是否对,给用户 密码，是否锁住用户 同时登入系统
                var flag = await signInManager
                     .CheckPasswordSignInAsync(user, vm.Password, false);
                if (flag.Succeeded)
                {//登入系统
                    await signInManager.SignInAsync(user, true);
                    if(User.IsInRole("SysAdmin"))
                        return RedirectToAction("Index", "Home",new {area="Admin"});
                    if (returnUrl != null)
                        return Redirect(returnUrl);
                    else
                        return RedirectToAction("Index", "Home");

                }
                else
                {
                    ViewBag.Msg = "passowrd error";
                    return View();
                }
                    
            }
            else//找不到了
            {
                ViewBag.Msg = "user no";
                return View();
            }
                
        }

        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}

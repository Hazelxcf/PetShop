﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.ViewModels
{
    public class RegisterViewModel
    {
        public String UserName { get; set; }
        public String Password { get; set; }
        public String Password2 { get; set; }
        public String Address { get; set; }
        public String RealName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.ViewModels
{
    public class LoginViewModel
    {
        public String UserName { get; set; }
        public String Password { get; set; }
    }
}

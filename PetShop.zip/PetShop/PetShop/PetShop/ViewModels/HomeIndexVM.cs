﻿using PetShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.ViewModels
{
    //首页得Viewmodel
    public class HomeIndexVM
    {
        public List<Dog> Dogs { get; set; }
        public List<DogType> DogTypes { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.ViewModels
{
    public class ChangePwdVM
    {
        public String UserName { get; set; }
        public String OldPassword { get; set; }
        public String NewPassword { get; set; }
        public String NewPassword2 { get; set; }
    }
}

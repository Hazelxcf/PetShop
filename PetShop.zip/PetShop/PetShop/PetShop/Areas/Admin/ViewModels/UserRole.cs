﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Area.Admin.ViewModels
{
    public class UserRole
    {
        public string UserID { get; set; }
        public string RoleId { get; set; }
        public string UserName { get; set; }
        public string RealName { get; set; }
        public string RoleName { get; set; }
    }
}

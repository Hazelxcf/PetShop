﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PetShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Area.Admin.Controllers
{
    [Area("Admin")]
    public class UserController : Controller
    {
        private UserManager<AppUser> userManager;
      

       
        public UserController(UserManager<AppUser> userManager
            )
        {
            this.userManager = userManager;
           
        }
        public IActionResult Index()
        {
            var list = userManager.Users
                 .ToList();
            return View(list);
        }

        public async Task<IActionResult> Delete(string id)
        {
            var user = await userManager.FindByIdAsync(id);
            if (user != null)
            {
                var result = await userManager.DeleteAsync(user);
                if (result.Succeeded)
                    return RedirectToAction("Index");

            }
            ModelState.AddModelError(string.Empty, "删除出现错误");
            return RedirectToAction("Index", "User", new { area = "Admin" });
        }
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PetShop.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Areas.Admin.Controllers
{
    [Area("Admin")]
    // [Authorize(Roles = "SysAdmin")]
    //狗的添加、修改、删除
    public class DogController : Controller
    {
        DogDbContext context;
        IWebHostEnvironment hostingEnvironment;
        public DogController(DogDbContext context,IWebHostEnvironment hostingEnvironment)
        {
            this.context = context;
            this.hostingEnvironment = hostingEnvironment;
        }
        public IActionResult Index()
        {
            
            return View(context.Dogs.ToList());
        }
        
            [HttpGet]
        public IActionResult Add()
        {
            List<DogType> types = null;
            ///添加代码，通过数据库查询所有的Type，生成列表，并将结果送给types
            types = context.DogType.ToList();
            SelectList list = new SelectList(types, "TypeId", "TypeName");
            //上面这一句是生成下拉框list的选项，注意这次从数据库中types，然后设置下拉框背后值是Typeid，下拉框内容显示TppeName
            ViewBag.Type = list;
            return View();
        }
        [HttpPost]
        public IActionResult Add(Dog dog)
        {
            //这部分完成了图片上传
            String fileName = "default.png";
            dog.ImgURL = "/upload/" + fileName;
            if (dog.Photo != null)
            {
                string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "upload");
                fileName = Guid.NewGuid().ToString() + "_" + dog.Photo.FileName;
                string filePath = Path.Combine(uploadsFolder, fileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    dog.Photo.CopyTo(fileStream);

                }
                dog.ImgURL = "/upload/" + fileName;
                dog.Photo = null;
            }
            //添加代码，把dog对象保存到数据表中
            context.Dogs.Add(dog);
            context.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult Del(int id)
        {
            //完成删除id是主键的值
          var  dog = context.Dogs.Single(b => b.Id == id);
            context.Dogs.Remove(dog);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Update(int id)
        {
            Dog dog = null;
            //根据id查询出一个dog的信息，送给dog变量
            // dog = context.Dogs.Find(id);//key
            dog = context.Dogs.Single(b => b.Id == id);
            var types = context.DogType.ToList();
            SelectList list = new SelectList(types, "TypeId", "TypeName", dog.TypeId);
            ViewBag.Type = list;
            return View(dog);

        }
        [HttpPost]
        public IActionResult Update(Dog dog)
        {
            var d = context.Dogs.AsNoTracking().ToList()
                              .FirstOrDefault(dc => dc.Id == dog.Id);
            dog.ImgURL = d.ImgURL;
            if (dog.Photo != null)
            {
                string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "upload");
                string fileName = Guid.NewGuid().ToString() + "_" + dog.Photo.FileName;
                string filePath = Path.Combine(uploadsFolder, fileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    dog.Photo.CopyTo(fileStream);

                }
                dog.ImgURL = "/upload/" + fileName;
                dog.Photo = null;
            }
            //添加代码，完成将dog对象更新到数据库中
            context.Dogs.Update(dog);
            context.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult Detail(int id)
        {
           
            /// 根据id查询一条狗信息并保存到dog对象中
            var dog = context.Dogs.Find(id);
            //根据dog的TYpeId查询TypeName 送到viewBag
            ViewBag.TypeName = context.DogType.Find(dog.TypeId).TypeName;
            //修改返回，将dog对象并传送到view的Model中
            return View(dog);
        }
        //查询代码，完成根据狗的名称dogName，查询所有包括这个名字的dog，并在首页上显示
        public IActionResult Search(string dogName)
        {//
            List<Dog> list = null;
            //添加查询代码，完成根据狗的名称dogName，查询所有包括这个名字的dog，存到list中
            list = context.Dogs.
                Where(b => b.Name.Contains(dogName)).ToList();

            return View("Index", list);//返回视图到Index，并传递数据list
        }



    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PetShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class DogTypeController : Controller
    {
        DogDbContext context;
        public DogTypeController(DogDbContext context)
        {
            this.context = context;
        }

        //查看所有狗的类型
        public IActionResult Index()
        {
            //查询所有类型，作为一个list，传递到Index视图中
            var list = context.DogType.ToList();
            return View(list);
        }
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(DogType type)
        {
            //将type对象，包存放到数据库中
            context.DogType.Add(type);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Del(int id)
        {
            //根据id 查询一个type对象出来，然后把它从数据库中删除
            var type = context.DogType.Find(id);//find方法查某个对象，关键字查
            context.DogType.Remove(type);
            context.SaveChanges();
            return RedirectToAction("Index"); ;
        }
    }
}

﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PetShop.Area.Admin.ViewModels;
using PetShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Areas.Admin.Controllers
{
    [Area("Admin")]
    //[Authorize(Roles ="SysAdmin")]
    public class RolesController : Controller
    {
        private UserManager<AppUser> userManager;
        private RoleManager<IdentityRole> roleManager;

        
        public RolesController(UserManager<AppUser> userManager
            , RoleManager<IdentityRole> roleManager)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            
        }
        public IActionResult Index()
        {
            var roleList = roleManager.Roles.ToList();
            return View(roleList);
        }
        //添加一个角色
        [HttpPost]
        public async Task<IActionResult> Create([Bind("Name")] string Name)
        {
            var role = new IdentityRole() { Name = Name };
            // var role = new IdentityRole() { Name = "SysAdmin" };
            var result = await roleManager.CreateAsync(role);
            if (result.Succeeded)
            {
                return RedirectToAction("Index", "roles", new { area = "Admin" });
            }

            return View();
        }

        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }
        public async Task<IActionResult> GetUserWithRole()
        {
            List<UserRole> userRoles = new List<UserRole>();
            var roles = roleManager.Roles.ToList();
            foreach (var role in roles)
            {
                var userlist = await userManager.GetUsersInRoleAsync(role.Name);
                foreach (var use in userlist)
                {

                    userRoles.Add(new UserRole()
                    {
                        UserID = use.Id,
                        UserName = use.UserName,
                        RealName = use.RealName,
                        RoleId = role.Id,
                        RoleName = role.Name
                    });
                }
            }
            foreach (var use in userManager.Users)
            {
                bool flag = true;
                foreach (var role in roleManager.Roles)
                {
                    if (await userManager.IsInRoleAsync(use, role.Name))
                    { flag = false; break; }
                }
                if (flag)
                {
                    userRoles.Add(new UserRole()
                    {
                        UserID = use.Id,
                        UserName = use.UserName,
                        RealName = use.RealName
                    });
                }
            }
            return View(userRoles);
        }

        [HttpPost]
        //查出某个角色拥有的用户
        public async Task<IActionResult> GetUserWithRole(string ID)
        {
            var users = await userManager.GetUsersInRoleAsync("SysAdmin");
            return View(users);
        }
        [HttpGet]
        public async Task<IActionResult> AddUserRole(string id)
        {
            var user = await userManager.FindByIdAsync(id);
            if (user != null)
            {
                ViewBag.UserName = user.UserName;
                var rolelist = roleManager.Roles;
                ViewBag.roleSelects = new SelectList(
                    rolelist, "Id", "Name");
                ViewBag.UserId = user.Id;
                return View();
            }
            return View();

        }
        [HttpPost]
        public async Task<IActionResult> AddUserRole([Bind("UserId", "UserName", "RoleId")] string id, string userName, string roleId)
        {
            var user = await userManager.FindByIdAsync(id);
            if (user != null)
            {
                var role = await roleManager.FindByIdAsync(roleId);
                var result = await userManager.AddToRoleAsync(user, role.Name);
                if (result.Succeeded)
                    return RedirectToAction("GetUserWithRole", "Roles", new { area = "Admin" });

            }
            return View();

        }

        public async Task<IActionResult> ChangeUserRole(string id, string roleid, string rolename)

        {
            var user = await userManager.FindByIdAsync(id);

            if (user != null)
            {

                ViewBag.UserName = user.UserName;
                var rolelist = roleManager.Roles;
                ViewBag.roleSelects = new SelectList(
                    rolelist, "Id", "Name", roleid);
                ViewBag.UserId = user.Id;
                ViewBag.roleName = rolename;
                return View();
            }
            return RedirectToAction("GetUserWithRole", "Roles", new { area = "Admin" });
        }

        [HttpPost]
        public async Task<IActionResult> ChangeUserRole([Bind("UserId", "UserName", "RoleId", "rolename")] string id, string userName, string roleId, string rolename)
        {
            var user = await userManager.FindByIdAsync(id);
            if (user != null)
            {
                await userManager.RemoveFromRoleAsync(user, rolename);
                var role = await roleManager.FindByIdAsync(roleId);
                var result = await userManager.AddToRoleAsync(user, role.Name);
                if (result.Succeeded)
                    return RedirectToAction("GetUserWithRole", "Roles", new { area = "Admin" });

            }
            return View();
        }

        public async Task<IActionResult> DeleteUserRole(string id, string rolename)
        {
            var user = await userManager.FindByIdAsync(id);
            if (user != null)
            {
                var result = await userManager.RemoveFromRoleAsync(user, rolename);
                if (result.Succeeded)
                    return RedirectToAction("GetUserWithRole", "Roles", new { area = "Admin" });
            }

            return View();

        }
    }
}

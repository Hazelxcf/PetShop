﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class DogType
    {
        [Key]
        public int TypeId { get; set; }
        public String TypeName { get; set; }

        //集合导航属性 规定狗和狗类型的关系
        public List<Dog> Dogs { get; set; }
    }
}

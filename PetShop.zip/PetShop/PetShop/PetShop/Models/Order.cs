﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }
        public DateTime CreateTime { get; set; }

        public bool status { get; set; }

        public double Money { get; set; }
        //导航属性
        public AppUser AppUser { get; set; }

        public List<OrderDetail> OrderDetails { get; set; }
    }
}

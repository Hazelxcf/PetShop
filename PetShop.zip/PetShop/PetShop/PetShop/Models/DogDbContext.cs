﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class DogDbContext:IdentityDbContext<AppUser>
    {
        public DbSet<Dog> Dogs { get; set; }
        public DbSet<DogType> DogType { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        public DogDbContext(DbContextOptions<DogDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            base.OnModelCreating(builder);
            builder.Entity<Order>()
                 .Property(c => c.CreateTime)
                 .HasDefaultValueSql("getDate()");

            builder.Entity<Order>()
                .Property(c => c.status)
                .HasDefaultValue(false);
        }
    }
}

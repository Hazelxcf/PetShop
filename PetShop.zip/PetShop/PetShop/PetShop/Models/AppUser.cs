﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class AppUser:IdentityUser
    {
        public string Address { get; set; }
        public string RealName { get; set; }
        //
        public virtual List<Order> Orders { get; set; }
    }
}

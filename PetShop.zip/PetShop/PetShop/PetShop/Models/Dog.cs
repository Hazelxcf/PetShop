﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    public class Dog
    {
        [Key]
        public int Id { get; set; }
        //非空 字段长度为nvarchar(100)
        [Column(TypeName = "nvarchar(100)")]
        [Required]
        public String Name { get; set; }

        public Gender Gender { get; set; }
        public DateTime Birthday { get; set; }
        public double Price { get; set; }
        public String ImgURL { get; set; }
        public String Description { get; set; }
        [NotMapped] //不映射到数据表中
        public IFormFile Photo { get; set; }

        //引用导航属性 一个狗属于一种类型
        [ForeignKey("OrderId")]
        public int TypeId { get; set; }//品种的id 外键
        public DogType DogType { get; set; }

    }
    public enum Gender
    {
        male = 0, female = 1, other = 2
    }
}

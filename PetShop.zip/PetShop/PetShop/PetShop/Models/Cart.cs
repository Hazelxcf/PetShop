﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShop.Models
{
    //完整的购物车
    public class Cart
    {
        //描述购物车的中能存储的物品
        private List<CartLine> lineCollection = new List<CartLine>();

        //添加
        public void AddItem(Dog product, int quantity)
        {
            CartLine line = lineCollection.Where(p => p.Id == product.Id).FirstOrDefault();
            if (line == null)
            {
                lineCollection.Add(new CartLine() { Id = product.Id, Name = product.Name, Quantity = quantity, Price = product.Price, ImageUrl = product.ImgURL });
            }
            else
            {
                line.Quantity += quantity;
            }
        }

        //点击数量+号或点击数量-号或自己输入一个值
        public void IncreaseOrDecreaseOne(Dog product, int quantity)
        {
            CartLine line = lineCollection.Where(p => p.Id == product.Id).FirstOrDefault();
            if (line != null)
            {
                line.Quantity = quantity;
            }
            else
            {
                lineCollection.Add(new CartLine() { Id = product.Id, Name = product.Name, Quantity = quantity, Price = product.Price, ImageUrl = product.ImgURL });
            }
        }

        //移除
        public void RemoveLine(Dog product)
        {
            lineCollection.RemoveAll(p => p.Id == product.Id);

        }
        public void RemoveLine(int id)
        {
            lineCollection.RemoveAll(p => p.Id == id);
        }
        //计算总价
        public decimal ComputeTotalPrice()
        {
            return lineCollection.Sum(p => (decimal)p.Price * p.Quantity);
        }

        //清空
        public void Clear()
        {
            lineCollection.Clear();
        }

        //获取
        public IEnumerable<CartLine> Lines
        {
            get { return lineCollection; }
        }
    }
}
